// Download failed for https://kelee.one/Resource/JavaScript/WexinMiniPrograms/alittle-tea/alittle-tea.js
// HTTP Error 403: Forbidden
$done({});
