// Download failed for https://kelee.one/Resource/JavaScript/NeteaseNews/NeteaseNews_remove_ads.js
// HTTP Error 403: Forbidden
$done({});
