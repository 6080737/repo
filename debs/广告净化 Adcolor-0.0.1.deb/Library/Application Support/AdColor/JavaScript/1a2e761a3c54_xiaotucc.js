// Download failed for https://kelee.one/Resource/JavaScript/WexinMiniPrograms/xiaotucc/xiaotucc.js
// HTTP Error 403: Forbidden
$done({});
