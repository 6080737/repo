// Download failed for https://kelee.one/Resource/JavaScript/WexinMiniPrograms/ming/ming.js
// HTTP Error 403: Forbidden
$done({});
