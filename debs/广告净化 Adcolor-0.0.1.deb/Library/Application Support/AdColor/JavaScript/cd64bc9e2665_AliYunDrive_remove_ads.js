// Download failed for https://kelee.one/Resource/JavaScript/AliYunDrive/AliYunDrive_remove_ads.js
// HTTP Error 403: Forbidden
$done({});
