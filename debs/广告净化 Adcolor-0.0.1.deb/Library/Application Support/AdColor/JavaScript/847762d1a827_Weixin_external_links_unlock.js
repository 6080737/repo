// Download failed for https://kelee.one/Resource/JavaScript/Weixin/Weixin_external_links_unlock.js
// HTTP Error 403: Forbidden
$done({});
