// Download failed for https://kelee.one/Resource/JavaScript/YouTube/YouTube_Subtitles_Translate/YouTube_Subtitles_request.js
// HTTP Error 403: Forbidden
$done({});
