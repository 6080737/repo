// Download failed for https://kelee.one/Resource/JavaScript/WexinMiniPrograms/qingju/qingju.js
// HTTP Error 403: Forbidden
$done({});
