// Download failed for https://kelee.one/Resource/JavaScript/MKZ/MKZ_remove_ads.js
// HTTP Error 403: Forbidden
$done({});
