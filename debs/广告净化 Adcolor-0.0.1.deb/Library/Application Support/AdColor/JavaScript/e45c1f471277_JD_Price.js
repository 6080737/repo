// Download failed for https://kelee.one/Resource/JavaScript/JD/JD_Price.js
// HTTP Error 403: Forbidden
$done({});
