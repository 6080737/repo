// Download failed for https://kelee.one/Resource/JavaScript/WexinMiniPrograms/M_Stand/M_Stand.js
// HTTP Error 403: Forbidden
$done({});
