// Download failed for https://kelee.one/Resource/JavaScript/iMaiCai/iMaiCai_remove_ads.js
// HTTP Error 403: Forbidden
$done({});
