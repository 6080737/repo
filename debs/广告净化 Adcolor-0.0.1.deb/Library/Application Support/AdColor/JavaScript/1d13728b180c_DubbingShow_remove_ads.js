// Download failed for https://kelee.one/Resource/JavaScript/DubbingShow/DubbingShow_remove_ads.js
// HTTP Error 403: Forbidden
$done({});
