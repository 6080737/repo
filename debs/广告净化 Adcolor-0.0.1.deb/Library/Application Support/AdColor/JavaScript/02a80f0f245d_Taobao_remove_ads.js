// Download failed for https://kelee.one/Resource/JavaScript/Taobao/Taobao_remove_ads.js
// HTTP Error 403: Forbidden
$done({});
