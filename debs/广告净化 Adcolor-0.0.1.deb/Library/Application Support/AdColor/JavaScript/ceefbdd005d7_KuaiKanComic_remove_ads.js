// Download failed for https://kelee.one/Resource/JavaScript/KuaiKanComic/KuaiKanComic_remove_ads.js
// HTTP Error 403: Forbidden
$done({});
