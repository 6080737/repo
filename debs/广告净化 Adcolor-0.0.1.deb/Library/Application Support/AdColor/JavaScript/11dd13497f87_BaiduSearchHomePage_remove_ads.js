// Download failed for https://kelee.one/Resource/JavaScript/BaiduSearch/BaiduSearchHomePage_remove_ads.js
// HTTP Error 403: Forbidden
$done({});
