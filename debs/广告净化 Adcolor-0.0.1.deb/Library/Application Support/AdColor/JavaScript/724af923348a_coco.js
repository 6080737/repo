// Download failed for https://kelee.one/Resource/JavaScript/WexinMiniPrograms/coco/coco.js
// HTTP Error 403: Forbidden
$done({});
