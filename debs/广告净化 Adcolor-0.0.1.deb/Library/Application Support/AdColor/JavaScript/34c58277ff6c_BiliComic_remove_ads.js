// Download failed for https://kelee.one/Resource/JavaScript/BiliComic/BiliComic_remove_ads.js
// HTTP Error 403: Forbidden
$done({});
