// Download failed for https://kelee.one/Resource/JavaScript/MeituMYXJ/MeituMYXJ_remove_ads.js
// HTTP Error 403: Forbidden
$done({});
