// Download failed for https://kelee.one/Resource/JavaScript/Amap/Amap_remove_ads.js
// HTTP Error 403: Forbidden
$done({});
