// Download failed for https://kelee.one/Resource/JavaScript/Spotify/Spotify_remove_ads.js
// HTTP Error 403: Forbidden
$done({});
