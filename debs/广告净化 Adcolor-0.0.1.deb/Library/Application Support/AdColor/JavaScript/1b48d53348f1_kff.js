// Download failed for https://kelee.one/Resource/JavaScript/WexinMiniPrograms/kff/kff.js
// HTTP Error 403: Forbidden
$done({});
