// Download failed for https://kelee.one/Resource/JavaScript/KebidaDushu/KebidaDushu_remove_ads.js
// HTTP Error 403: Forbidden
$done({});
