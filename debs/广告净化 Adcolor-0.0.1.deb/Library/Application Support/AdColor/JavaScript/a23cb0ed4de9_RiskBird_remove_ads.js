// Download failed for https://kelee.one/Resource/JavaScript/RiskBird/RiskBird_remove_ads.js
// HTTP Error 403: Forbidden
$done({});
