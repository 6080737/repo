// Download failed for https://kelee.one/Resource/JavaScript/Douyu/Douyu_remove_ads.js
// HTTP Error 403: Forbidden
$done({});
