// Download failed for https://kelee.one/Resource/JavaScript/IThome/IThome_remove_ads.js
// HTTP Error 403: Forbidden
$done({});
