// Download failed for https://kelee.one/Resource/JavaScript/NeteaseCloudMusic/NeteaseCloudMusic_remove_ads.js
// HTTP Error 403: Forbidden
$done({});
