// Download failed for https://kelee.one/Resource/JavaScript/WexinMiniPrograms/lawson/lawson.js
// HTTP Error 403: Forbidden
$done({});
