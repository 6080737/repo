// Download failed for https://kelee.one/Resource/JavaScript/WexinMiniPrograms/T3/T3.js
// HTTP Error 403: Forbidden
$done({});
