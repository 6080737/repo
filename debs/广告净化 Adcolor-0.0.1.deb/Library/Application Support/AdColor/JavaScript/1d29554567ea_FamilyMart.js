// Download failed for https://kelee.one/Resource/JavaScript/WexinMiniPrograms/FamilyMart/FamilyMart.js
// HTTP Error 403: Forbidden
$done({});
