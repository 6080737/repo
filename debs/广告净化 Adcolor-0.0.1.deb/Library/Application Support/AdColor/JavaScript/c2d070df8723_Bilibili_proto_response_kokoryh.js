// Download failed for https://kelee.one/Resource/JavaScript/Bilibili/Bilibili_proto_response_kokoryh.js
// HTTP Error 403: Forbidden
$done({});
